package propertytaxes;

import javax.swing.*;    // Needed for Swing classes
import java.awt.event.*; // Needed for ActionListener Interface
import java.text.NumberFormat;

/**
 *
 * @author gaben
 */
public class PropertyTaxes extends JFrame {
   private JPanel panel;             // To reference a panel
   private JLabel messageLabel;      // To reference a label
   private JTextField propField; // To reference a text field
   private JButton calcButton;       // To reference a button
   private final int WINDOW_WIDTH = 400;  // Window width
   private final int WINDOW_HEIGHT = 170; // Window height
   
   public PropertyTaxes()
   {
      setTitle("Property Taxes");
      setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      buildPanel();
      add(panel);
      setVisible(true);
   }
   
   private void buildPanel() {
      messageLabel = new JLabel("Enter the actual property value: ");
      propField = new JTextField(20);
      calcButton = new JButton("Calculate Property Tax");
      calcButton.addActionListener(new CalculateListener());
      panel = new JPanel();
      panel.add(messageLabel);
      panel.add(propField);
      panel.add(calcButton);
   }
    
   private class CalculateListener implements ActionListener
   {

      public void actionPerformed(ActionEvent e)
      {
         final double percentage = 0.60;
         String input;
         input = propField.getText();
         double assessVal = Double.parseDouble(input) * percentage;
         double propTax = (assessVal / 100) * 0.64;
         String assessValForm = String.format("%,.2f", assessVal);
         String propTaxForm = String.format("%,.2f", propTax);
         JOptionPane.showMessageDialog(null,"Assessment Value: $" + assessValForm +"\nProperty Tax: $" + propTaxForm);
      }
   }
   
   public static void main(String[] args) {
        new PropertyTaxes();
    }
    
}
